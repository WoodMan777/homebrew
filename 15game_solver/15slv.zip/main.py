import tools

global total_positions

initial_state = "1 4 8 14 5 6 9 12 2 0 10 15 3 7 11 13" #column-by-column
initial_state = "0 4 8 12 1 5 9 13 2 6 10 14 3 7 11 15"

depth = 13



arr = tools.strTo2dArray(initial_state)
game = tools.Board(initial_state)
print(game.getAllPossibleMoves())

all_boards = []
perfect_solutions = []

#LRUD

def recursive_exploration(game :tools.Board, current_depth, max_depth):
    possible_moves = game.getAllPossibleMoves()
    if game.position not in all_boards:
        all_boards.append(game.position)
        perfect_solutions.append(current_depth)
    else:
        solution = all_boards.index(game.position)
        if perfect_solutions[solution] > current_depth:
            perfect_solutions[solution] = current_depth

    
    if current_depth == max_depth:
        return

    if possible_moves & 8:
        tmp = tools.Board(game)
        tmp.makeMoveLeft()
        recursive_exploration(tmp,current_depth+1, max_depth)
    
    if possible_moves & 4:
        tmp = tools.Board(game)
        tmp.makeMoveRight()
        recursive_exploration(tmp,current_depth+1, max_depth)
    
    if possible_moves & 2:
        tmp = tools.Board(game)
        tmp.makeMoveUp()
        recursive_exploration(tmp,current_depth+1, max_depth)
    
    if possible_moves & 1:
        tmp = tools.Board(game)
        tmp.makeMoveDown()
        recursive_exploration(tmp,current_depth+1, max_depth)

#for depth in range(1,12):
#    recursive_exploration(game,0,depth)
#    print(f"Positions found to depth {depth}: {len(all_boards)}")

recursive_exploration(game, 0, depth)

file_out = open("prefect_solutions.txt", "w+")

for i in range(len(all_boards)):
    file_out.write(f"{tools.TwoDArrayToStr(all_boards[i])} : {perfect_solutions[i]}\n")


# print(game.isSolved())
# print(str(game))